import React from 'react';

import H3 from './H3';

export default {
  title: 'H3',
  component: H3,
};

export const primary = () => <H3>Heading 3</H3>;
