import React from 'react';
import { H1, H2, H3, Paragraph } from '.';

export default {
  title: 'All',
};

export const All = () => (
  <div>
    <H1>Heading 1</H1>
    <H2>Heading 1</H2>
    <H3>Heading 1</H3>
    <Paragraph>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Officia,
      reiciendis!
    </Paragraph>
  </div>
);
