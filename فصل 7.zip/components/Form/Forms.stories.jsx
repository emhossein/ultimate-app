import React from 'react';

import Form from './Form';

export default {
  title: 'Forms',
};

export const contactForm = () => <Form />;
