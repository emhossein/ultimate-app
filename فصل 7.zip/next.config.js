module.exports = {
  reactStrictMode: true,
  images: {
    domains: ['s4.uupload.ir'],
  },
};
