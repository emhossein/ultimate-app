import React from 'react';

import HyperLink from './HyperLink';

export default {
  title: 'Hyper Link',
};

export const hyperLink = () => <HyperLink link="/">This is a Link</HyperLink>;
