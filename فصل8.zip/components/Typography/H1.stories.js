import React from 'react';

import H1 from './H1';

export default {
  title: 'H1',
  component: H1,
};

export const primary = () => <H1>Heading 1</H1>;
