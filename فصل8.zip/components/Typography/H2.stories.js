import React from 'react';

import H2 from './H2';

export default {
  title: 'H2',
  component: H2,
};

export const primary = () => <H2>Heading 2</H2>;
