import React from 'react';
import { Cart } from '../components';

const cart = () => {
  return (
    <div>
      <Cart />
    </div>
  );
};

export default cart;
